package com.sample;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
//@EnableRetry
public class DashboardDataApplication
{
	private static final Logger LOGGER = LoggerFactory.getLogger(DashboardDataApplication.class);


	public static void main(String[] args)
	{
		// Launch the application
		ConfigurableApplicationContext context = SpringApplication
				.run(DashboardDataApplication.class, args);

	}

}
