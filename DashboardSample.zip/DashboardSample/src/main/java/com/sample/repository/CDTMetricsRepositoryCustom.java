package com.sample.repository;

import com.sample.model.CDTMetricsVo;

public interface CDTMetricsRepositoryCustom {
    CDTMetricsVo findLatestByArtifactId(String artifactId);
}

