package com.sample.repository;

import com.sample.model.CIMetricsVo;

public interface CIMetricsRepositoryCustom {
    CIMetricsVo findByArtifactId(String artifactId);
}
