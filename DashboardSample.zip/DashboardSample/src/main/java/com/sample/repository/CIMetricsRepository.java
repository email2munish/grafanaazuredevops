package com.sample.repository;

import com.sample.model.CIMetricsVo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CIMetricsRepository extends JpaRepository<CIMetricsVo, String>, CIMetricsRepositoryCustom {
}
