package com.sample.repository;

import com.sample.model.CDTMetricsVo;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

@Repository
public class CDTMetricsRepositoryImpl implements CDTMetricsRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public CDTMetricsVo findLatestByArtifactId(String artifactId) {
        String jpql = "SELECT c FROM CDTMetricsVo c WHERE c.artifactId = :artifactId ORDER BY c.cdDate DESC";
        TypedQuery<CDTMetricsVo> query = entityManager.createQuery(jpql, CDTMetricsVo.class);
        query.setParameter("artifactId", artifactId);
        query.setMaxResults(1);
        return query.getResultStream().findFirst().orElse(null);
    }
}
