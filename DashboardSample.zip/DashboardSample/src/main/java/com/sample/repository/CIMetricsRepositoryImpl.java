package com.sample.repository;

import com.sample.model.CIMetricsVo;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

@Repository
public class CIMetricsRepositoryImpl implements CIMetricsRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public CIMetricsVo findByArtifactId(String artifactId) {
        String jpql = "SELECT c FROM CIMetricsVo c WHERE c.artifactId = :artifactId";
        TypedQuery<CIMetricsVo> query = entityManager.createQuery(jpql, CIMetricsVo.class);
        query.setParameter("artifactId", artifactId);
        return query.getResultStream().findFirst().orElse(null);
    }
}