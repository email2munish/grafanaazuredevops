package com.sample.repository;

import com.sample.model.CDTMetricsVo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CDTMetricsRepository extends JpaRepository<CDTMetricsVo, String>, CDTMetricsRepositoryCustom {
}

