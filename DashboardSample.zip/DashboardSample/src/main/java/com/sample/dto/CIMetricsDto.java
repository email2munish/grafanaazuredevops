package com.sample.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.OffsetDateTime;

public class CIMetricsDto implements Serializable {

    private String buildId;
	private String serviceName;
	private String branchName;
    private String groupName;
    private String areaName;

    private String artifactId;
    private String actionType;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private OffsetDateTime ciDate;

    private Integer sqrIssues;
    private Integer newSqrIssues;
    private String sqrRating;
    private String newSqrRating;
    private String sqrRemediationEffort;
    private String newSqrRemediationEffort;

    private Integer sqmIssues;
    private Integer newSqmIssues;
    private String sqmRemediationEffort;
    private String newSqmRemediationEffort;
    private String sqmDebtRatio;
    private String newSqmDebtRatio;
    private String sqmRating;
    private String newSqmRating;

    private Integer coverage;
    private Integer newCoverage;
    private Integer linesToCover;
    private Integer newLinesToCover;
    private Integer uncoveredLines;
    private Integer newUncoveredLines;

    private Integer tests;
    private Integer testErrors;
    private Integer testFailures;
    private Integer skippedTests;
    private Integer testExecutionTime;
    private Integer testSuccessDensity;

    private Integer duplicatedLinesDensity;
    private Integer newDuplicatedLinesDensity;
    private Integer duplicatedLines;
    private Integer duplicatedBlocks;
    private Integer newDuplicatedBlocks;
    private Integer duplicatedFiles;

    private Integer newLines;
    private Integer ncloc;
    private Integer lines;
    private Integer statements;
    private Integer functions;
    private Integer classes;
    private Integer files;
    private Integer commentLines;
    private Integer commentLinesDensity;

    private Integer complexity;
    private Integer cognitiveComplexity;

    private Integer violations;
    private Integer newViolations;
    private Integer openIssues;
    private Integer acceptedIssues;
    private Integer falsePositiveIssues;
    private Integer softwareQualityBlockerIssues;
    private Integer softwareQualityHighIssues;
    private Integer softwareQualityMediumIssues;
    private Integer softwareQualityLowIssues;

    private Integer sastIssueLow;
    private Integer sastIssueMedium;
    private Integer sastIssueHigh;
    private Integer sastIssueCritical;
    private Integer sastIssueBlocker;
    private Integer sastIssueTotal;

    private Integer scaIssueLow;
    private Integer scaIssueMedium;
    private Integer scaIssueHigh;
    private Integer scaIssueCritical;
    private Integer scaIssueBlocker;
    private Integer scaIssueTotal;

    private Integer twistVulnerabilitiesLow;
    private Integer twistVulnerabilitiesMedium;
    private Integer twistVulnerabilitiesHigh;
    private Integer twistVulnerabilitiesCritical;
    private Integer twistVulnerabilitiesBlocker;
    private Integer twistVulnerabilitiesTotal;

    private Integer twistComplianceLow;
    private Integer twistComplianceMedium;
    private Integer twistComplianceHigh;
    private Integer twistComplianceCritical;
    private Integer twistComplianceBlocker;
    private Integer twistComplianceTotal;

    private String pipelineStatus;
    public String getServiceName() {
		return serviceName;
	}


	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	public String getBranchName() {
		return branchName;
	}


	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}


	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public String getAreaName() {
		return areaName;
	}


	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	private Integer pipelineDuration;
    
    
    @Override
	public String toString() {
		return "CIMetricsDto [buildId=" + buildId + ", artifactId=" + artifactId + ", actionType=" + actionType
				+ ", ciDate=" + ciDate + ", sqrIssues=" + sqrIssues + ", newSqrIssues=" + newSqrIssues + ", sqrRating="
				+ sqrRating + ", newSqrRating=" + newSqrRating + ", sqrRemediationEffort=" + sqrRemediationEffort
				+ ", newSqrRemediationEffort=" + newSqrRemediationEffort + ", sqmIssues=" + sqmIssues
				+ ", newSqmIssues=" + newSqmIssues + ", sqmRemediationEffort=" + sqmRemediationEffort
				+ ", newSqmRemediationEffort=" + newSqmRemediationEffort + ", sqmDebtRatio=" + sqmDebtRatio
				+ ", newSqmDebtRatio=" + newSqmDebtRatio + ", sqmRating=" + sqmRating + ", newSqmRating=" + newSqmRating
				+ ", coverage=" + coverage + ", newCoverage=" + newCoverage + ", linesToCover=" + linesToCover
				+ ", newLinesToCover=" + newLinesToCover + ", uncoveredLines=" + uncoveredLines + ", newUncoveredLines="
				+ newUncoveredLines + ", tests=" + tests + ", testErrors=" + testErrors + ", testFailures="
				+ testFailures + ", skippedTests=" + skippedTests + ", testExecutionTime=" + testExecutionTime
				+ ", testSuccessDensity=" + testSuccessDensity + ", duplicatedLinesDensity=" + duplicatedLinesDensity
				+ ", newDuplicatedLinesDensity=" + newDuplicatedLinesDensity + ", duplicatedLines=" + duplicatedLines
				+ ", duplicatedBlocks=" + duplicatedBlocks + ", newDuplicatedBlocks=" + newDuplicatedBlocks
				+ ", duplicatedFiles=" + duplicatedFiles + ", newLines=" + newLines + ", ncloc=" + ncloc + ", lines="
				+ lines + ", statements=" + statements + ", functions=" + functions + ", classes=" + classes
				+ ", files=" + files + ", commentLines=" + commentLines + ", commentLinesDensity=" + commentLinesDensity
				+ ", complexity=" + complexity + ", cognitiveComplexity=" + cognitiveComplexity + ", violations="
				+ violations + ", newViolations=" + newViolations + ", openIssues=" + openIssues + ", acceptedIssues="
				+ acceptedIssues + ", falsePositiveIssues=" + falsePositiveIssues + ", softwareQualityBlockerIssues="
				+ softwareQualityBlockerIssues + ", softwareQualityHighIssues=" + softwareQualityHighIssues
				+ ", softwareQualityMediumIssues=" + softwareQualityMediumIssues + ", softwareQualityLowIssues="
				+ softwareQualityLowIssues + ", sastIssueLow=" + sastIssueLow + ", sastIssueMedium=" + sastIssueMedium
				+ ", sastIssueHigh=" + sastIssueHigh + ", sastIssueCritical=" + sastIssueCritical
				+ ", sastIssueBlocker=" + sastIssueBlocker + ", sastIssueTotal=" + sastIssueTotal + ", scaIssueLow="
				+ scaIssueLow + ", scaIssueMedium=" + scaIssueMedium + ", scaIssueHigh=" + scaIssueHigh
				+ ", scaIssueCritical=" + scaIssueCritical + ", scaIssueBlocker=" + scaIssueBlocker + ", scaIssueTotal="
				+ scaIssueTotal + ", twistVulnerabilitiesLow=" + twistVulnerabilitiesLow
				+ ", twistVulnerabilitiesMedium=" + twistVulnerabilitiesMedium + ", twistVulnerabilitiesHigh="
				+ twistVulnerabilitiesHigh + ", twistVulnerabilitiesCritical=" + twistVulnerabilitiesCritical
				+ ", twistVulnerabilitiesBlocker=" + twistVulnerabilitiesBlocker + ", twistVulnerabilitiesTotal="
				+ twistVulnerabilitiesTotal + ", twistComplianceLow=" + twistComplianceLow + ", twistComplianceMedium="
				+ twistComplianceMedium + ", twistComplianceHigh=" + twistComplianceHigh + ", twistComplianceCritical="
				+ twistComplianceCritical + ", twistComplianceBlocker=" + twistComplianceBlocker
				+ ", twistComplianceTotal=" + twistComplianceTotal + ", pipelineStatus=" + pipelineStatus
				+ ", pipelineDuration=" + pipelineDuration + "]";
	}

    
	public String getBuildId() {
		return buildId;
	}
	public void setBuildId(String buildId) {
		this.buildId = buildId;
	}
	public String getArtifactId() {
		return artifactId;
	}
	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public OffsetDateTime getCiDate() {
		return ciDate;
	}
	public void setCiDate(OffsetDateTime ciDate) {
		this.ciDate = ciDate;
	}
	public Integer getSqrIssues() {
		return sqrIssues;
	}
	public void setSqrIssues(Integer sqrIssues) {
		this.sqrIssues = sqrIssues;
	}
	public Integer getNewSqrIssues() {
		return newSqrIssues;
	}
	public void setNewSqrIssues(Integer newSqrIssues) {
		this.newSqrIssues = newSqrIssues;
	}
	public String getSqrRating() {
		return sqrRating;
	}
	public void setSqrRating(String sqrRating) {
		this.sqrRating = sqrRating;
	}
	public String getNewSqrRating() {
		return newSqrRating;
	}
	public void setNewSqrRating(String newSqrRating) {
		this.newSqrRating = newSqrRating;
	}
	public String getSqrRemediationEffort() {
		return sqrRemediationEffort;
	}
	public void setSqrRemediationEffort(String sqrRemediationEffort) {
		this.sqrRemediationEffort = sqrRemediationEffort;
	}
	public String getNewSqrRemediationEffort() {
		return newSqrRemediationEffort;
	}
	public void setNewSqrRemediationEffort(String newSqrRemediationEffort) {
		this.newSqrRemediationEffort = newSqrRemediationEffort;
	}
	public Integer getSqmIssues() {
		return sqmIssues;
	}
	public void setSqmIssues(Integer sqmIssues) {
		this.sqmIssues = sqmIssues;
	}
	public Integer getNewSqmIssues() {
		return newSqmIssues;
	}
	public void setNewSqmIssues(Integer newSqmIssues) {
		this.newSqmIssues = newSqmIssues;
	}
	public String getSqmRemediationEffort() {
		return sqmRemediationEffort;
	}
	public void setSqmRemediationEffort(String sqmRemediationEffort) {
		this.sqmRemediationEffort = sqmRemediationEffort;
	}
	public String getNewSqmRemediationEffort() {
		return newSqmRemediationEffort;
	}
	public void setNewSqmRemediationEffort(String newSqmRemediationEffort) {
		this.newSqmRemediationEffort = newSqmRemediationEffort;
	}
	public String getSqmDebtRatio() {
		return sqmDebtRatio;
	}
	public void setSqmDebtRatio(String sqmDebtRatio) {
		this.sqmDebtRatio = sqmDebtRatio;
	}
	public String getNewSqmDebtRatio() {
		return newSqmDebtRatio;
	}
	public void setNewSqmDebtRatio(String newSqmDebtRatio) {
		this.newSqmDebtRatio = newSqmDebtRatio;
	}
	public String getSqmRating() {
		return sqmRating;
	}
	public void setSqmRating(String sqmRating) {
		this.sqmRating = sqmRating;
	}
	public String getNewSqmRating() {
		return newSqmRating;
	}
	public void setNewSqmRating(String newSqmRating) {
		this.newSqmRating = newSqmRating;
	}
	public Integer getCoverage() {
		return coverage;
	}
	public void setCoverage(Integer coverage) {
		this.coverage = coverage;
	}
	public Integer getNewCoverage() {
		return newCoverage;
	}
	public void setNewCoverage(Integer newCoverage) {
		this.newCoverage = newCoverage;
	}
	public Integer getLinesToCover() {
		return linesToCover;
	}
	public void setLinesToCover(Integer linesToCover) {
		this.linesToCover = linesToCover;
	}
	public Integer getNewLinesToCover() {
		return newLinesToCover;
	}
	public void setNewLinesToCover(Integer newLinesToCover) {
		this.newLinesToCover = newLinesToCover;
	}
	public Integer getUncoveredLines() {
		return uncoveredLines;
	}
	public void setUncoveredLines(Integer uncoveredLines) {
		this.uncoveredLines = uncoveredLines;
	}
	public Integer getNewUncoveredLines() {
		return newUncoveredLines;
	}
	public void setNewUncoveredLines(Integer newUncoveredLines) {
		this.newUncoveredLines = newUncoveredLines;
	}
	public Integer getTests() {
		return tests;
	}
	public void setTests(Integer tests) {
		this.tests = tests;
	}
	public Integer getTestErrors() {
		return testErrors;
	}
	public void setTestErrors(Integer testErrors) {
		this.testErrors = testErrors;
	}
	public Integer getTestFailures() {
		return testFailures;
	}
	public void setTestFailures(Integer testFailures) {
		this.testFailures = testFailures;
	}
	public Integer getSkippedTests() {
		return skippedTests;
	}
	public void setSkippedTests(Integer skippedTests) {
		this.skippedTests = skippedTests;
	}
	public Integer getTestExecutionTime() {
		return testExecutionTime;
	}
	public void setTestExecutionTime(Integer testExecutionTime) {
		this.testExecutionTime = testExecutionTime;
	}
	public Integer getTestSuccessDensity() {
		return testSuccessDensity;
	}
	public void setTestSuccessDensity(Integer testSuccessDensity) {
		this.testSuccessDensity = testSuccessDensity;
	}
	public Integer getDuplicatedLinesDensity() {
		return duplicatedLinesDensity;
	}
	public void setDuplicatedLinesDensity(Integer duplicatedLinesDensity) {
		this.duplicatedLinesDensity = duplicatedLinesDensity;
	}
	public Integer getNewDuplicatedLinesDensity() {
		return newDuplicatedLinesDensity;
	}
	public void setNewDuplicatedLinesDensity(Integer newDuplicatedLinesDensity) {
		this.newDuplicatedLinesDensity = newDuplicatedLinesDensity;
	}
	public Integer getDuplicatedLines() {
		return duplicatedLines;
	}
	public void setDuplicatedLines(Integer duplicatedLines) {
		this.duplicatedLines = duplicatedLines;
	}
	public Integer getDuplicatedBlocks() {
		return duplicatedBlocks;
	}
	public void setDuplicatedBlocks(Integer duplicatedBlocks) {
		this.duplicatedBlocks = duplicatedBlocks;
	}
	public Integer getNewDuplicatedBlocks() {
		return newDuplicatedBlocks;
	}
	public void setNewDuplicatedBlocks(Integer newDuplicatedBlocks) {
		this.newDuplicatedBlocks = newDuplicatedBlocks;
	}
	public Integer getDuplicatedFiles() {
		return duplicatedFiles;
	}
	public void setDuplicatedFiles(Integer duplicatedFiles) {
		this.duplicatedFiles = duplicatedFiles;
	}
	public Integer getNewLines() {
		return newLines;
	}
	public void setNewLines(Integer newLines) {
		this.newLines = newLines;
	}
	public Integer getNcloc() {
		return ncloc;
	}
	public void setNcloc(Integer ncloc) {
		this.ncloc = ncloc;
	}
	public Integer getLines() {
		return lines;
	}
	public void setLines(Integer lines) {
		this.lines = lines;
	}
	public Integer getStatements() {
		return statements;
	}
	public void setStatements(Integer statements) {
		this.statements = statements;
	}
	public Integer getFunctions() {
		return functions;
	}
	public void setFunctions(Integer functions) {
		this.functions = functions;
	}
	public Integer getClasses() {
		return classes;
	}
	public void setClasses(Integer classes) {
		this.classes = classes;
	}
	public Integer getFiles() {
		return files;
	}
	public void setFiles(Integer files) {
		this.files = files;
	}
	public Integer getCommentLines() {
		return commentLines;
	}
	public void setCommentLines(Integer commentLines) {
		this.commentLines = commentLines;
	}
	public Integer getCommentLinesDensity() {
		return commentLinesDensity;
	}
	public void setCommentLinesDensity(Integer commentLinesDensity) {
		this.commentLinesDensity = commentLinesDensity;
	}
	public Integer getComplexity() {
		return complexity;
	}
	public void setComplexity(Integer complexity) {
		this.complexity = complexity;
	}
	public Integer getCognitiveComplexity() {
		return cognitiveComplexity;
	}
	public void setCognitiveComplexity(Integer cognitiveComplexity) {
		this.cognitiveComplexity = cognitiveComplexity;
	}
	public Integer getViolations() {
		return violations;
	}
	public void setViolations(Integer violations) {
		this.violations = violations;
	}
	public Integer getNewViolations() {
		return newViolations;
	}
	public void setNewViolations(Integer newViolations) {
		this.newViolations = newViolations;
	}
	public Integer getOpenIssues() {
		return openIssues;
	}
	public void setOpenIssues(Integer openIssues) {
		this.openIssues = openIssues;
	}
	public Integer getAcceptedIssues() {
		return acceptedIssues;
	}
	public void setAcceptedIssues(Integer acceptedIssues) {
		this.acceptedIssues = acceptedIssues;
	}
	public Integer getFalsePositiveIssues() {
		return falsePositiveIssues;
	}
	public void setFalsePositiveIssues(Integer falsePositiveIssues) {
		this.falsePositiveIssues = falsePositiveIssues;
	}
	public Integer getSoftwareQualityBlockerIssues() {
		return softwareQualityBlockerIssues;
	}
	public void setSoftwareQualityBlockerIssues(Integer softwareQualityBlockerIssues) {
		this.softwareQualityBlockerIssues = softwareQualityBlockerIssues;
	}
	public Integer getSoftwareQualityHighIssues() {
		return softwareQualityHighIssues;
	}
	public void setSoftwareQualityHighIssues(Integer softwareQualityHighIssues) {
		this.softwareQualityHighIssues = softwareQualityHighIssues;
	}
	public Integer getSoftwareQualityMediumIssues() {
		return softwareQualityMediumIssues;
	}
	public void setSoftwareQualityMediumIssues(Integer softwareQualityMediumIssues) {
		this.softwareQualityMediumIssues = softwareQualityMediumIssues;
	}
	public Integer getSoftwareQualityLowIssues() {
		return softwareQualityLowIssues;
	}
	public void setSoftwareQualityLowIssues(Integer softwareQualityLowIssues) {
		this.softwareQualityLowIssues = softwareQualityLowIssues;
	}
	public Integer getSastIssueLow() {
		return sastIssueLow;
	}
	public void setSastIssueLow(Integer sastIssueLow) {
		this.sastIssueLow = sastIssueLow;
	}
	public Integer getSastIssueMedium() {
		return sastIssueMedium;
	}
	public void setSastIssueMedium(Integer sastIssueMedium) {
		this.sastIssueMedium = sastIssueMedium;
	}
	public Integer getSastIssueHigh() {
		return sastIssueHigh;
	}
	public void setSastIssueHigh(Integer sastIssueHigh) {
		this.sastIssueHigh = sastIssueHigh;
	}
	public Integer getSastIssueCritical() {
		return sastIssueCritical;
	}
	public void setSastIssueCritical(Integer sastIssueCritical) {
		this.sastIssueCritical = sastIssueCritical;
	}
	public Integer getSastIssueBlocker() {
		return sastIssueBlocker;
	}
	public void setSastIssueBlocker(Integer sastIssueBlocker) {
		this.sastIssueBlocker = sastIssueBlocker;
	}
	public Integer getSastIssueTotal() {
		return sastIssueTotal;
	}
	public void setSastIssueTotal(Integer sastIssueTotal) {
		this.sastIssueTotal = sastIssueTotal;
	}
	public Integer getScaIssueLow() {
		return scaIssueLow;
	}
	public void setScaIssueLow(Integer scaIssueLow) {
		this.scaIssueLow = scaIssueLow;
	}
	public Integer getScaIssueMedium() {
		return scaIssueMedium;
	}
	public void setScaIssueMedium(Integer scaIssueMedium) {
		this.scaIssueMedium = scaIssueMedium;
	}
	public Integer getScaIssueHigh() {
		return scaIssueHigh;
	}
	public void setScaIssueHigh(Integer scaIssueHigh) {
		this.scaIssueHigh = scaIssueHigh;
	}
	public Integer getScaIssueCritical() {
		return scaIssueCritical;
	}
	public void setScaIssueCritical(Integer scaIssueCritical) {
		this.scaIssueCritical = scaIssueCritical;
	}
	public Integer getScaIssueBlocker() {
		return scaIssueBlocker;
	}
	public void setScaIssueBlocker(Integer scaIssueBlocker) {
		this.scaIssueBlocker = scaIssueBlocker;
	}
	public Integer getScaIssueTotal() {
		return scaIssueTotal;
	}
	public void setScaIssueTotal(Integer scaIssueTotal) {
		this.scaIssueTotal = scaIssueTotal;
	}
	public Integer getTwistVulnerabilitiesLow() {
		return twistVulnerabilitiesLow;
	}
	public void setTwistVulnerabilitiesLow(Integer twistVulnerabilitiesLow) {
		this.twistVulnerabilitiesLow = twistVulnerabilitiesLow;
	}
	public Integer getTwistVulnerabilitiesMedium() {
		return twistVulnerabilitiesMedium;
	}
	public void setTwistVulnerabilitiesMedium(Integer twistVulnerabilitiesMedium) {
		this.twistVulnerabilitiesMedium = twistVulnerabilitiesMedium;
	}
	public Integer getTwistVulnerabilitiesHigh() {
		return twistVulnerabilitiesHigh;
	}
	public void setTwistVulnerabilitiesHigh(Integer twistVulnerabilitiesHigh) {
		this.twistVulnerabilitiesHigh = twistVulnerabilitiesHigh;
	}
	public Integer getTwistVulnerabilitiesCritical() {
		return twistVulnerabilitiesCritical;
	}
	public void setTwistVulnerabilitiesCritical(Integer twistVulnerabilitiesCritical) {
		this.twistVulnerabilitiesCritical = twistVulnerabilitiesCritical;
	}
	public Integer getTwistVulnerabilitiesBlocker() {
		return twistVulnerabilitiesBlocker;
	}
	public void setTwistVulnerabilitiesBlocker(Integer twistVulnerabilitiesBlocker) {
		this.twistVulnerabilitiesBlocker = twistVulnerabilitiesBlocker;
	}
	public Integer getTwistVulnerabilitiesTotal() {
		return twistVulnerabilitiesTotal;
	}
	public void setTwistVulnerabilitiesTotal(Integer twistVulnerabilitiesTotal) {
		this.twistVulnerabilitiesTotal = twistVulnerabilitiesTotal;
	}
	public Integer getTwistComplianceLow() {
		return twistComplianceLow;
	}
	public void setTwistComplianceLow(Integer twistComplianceLow) {
		this.twistComplianceLow = twistComplianceLow;
	}
	public Integer getTwistComplianceMedium() {
		return twistComplianceMedium;
	}
	public void setTwistComplianceMedium(Integer twistComplianceMedium) {
		this.twistComplianceMedium = twistComplianceMedium;
	}
	public Integer getTwistComplianceHigh() {
		return twistComplianceHigh;
	}
	public void setTwistComplianceHigh(Integer twistComplianceHigh) {
		this.twistComplianceHigh = twistComplianceHigh;
	}
	public Integer getTwistComplianceCritical() {
		return twistComplianceCritical;
	}
	public void setTwistComplianceCritical(Integer twistComplianceCritical) {
		this.twistComplianceCritical = twistComplianceCritical;
	}
	public Integer getTwistComplianceBlocker() {
		return twistComplianceBlocker;
	}
	public void setTwistComplianceBlocker(Integer twistComplianceBlocker) {
		this.twistComplianceBlocker = twistComplianceBlocker;
	}
	public Integer getTwistComplianceTotal() {
		return twistComplianceTotal;
	}
	public void setTwistComplianceTotal(Integer twistComplianceTotal) {
		this.twistComplianceTotal = twistComplianceTotal;
	}
	public String getPipelineStatus() {
		return pipelineStatus;
	}
	public void setPipelineStatus(String pipelineStatus) {
		this.pipelineStatus = pipelineStatus;
	}
	public Integer getPipelineDuration() {
		return pipelineDuration;
	}
	public void setPipelineDuration(Integer pipelineDuration) {
		this.pipelineDuration = pipelineDuration;
	}

    // Constructors, Getters, Setters, and toString() can be generated via IDE or Lombok
}