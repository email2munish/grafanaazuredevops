package com.sample.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.OffsetDateTime;

public class CDTMetricsDto {

    private String buildId;
    private String artifactId;
    private String actionType;
    private String envLevel;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private OffsetDateTime cdDate;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private OffsetDateTime ctDate;

    private String startedBy;
    private String approver;
    private String deploymentStatus;

    private Integer totalTests;
    private Integer passedTests;
    private Integer failedTests;
    private Integer notrunTests;
    private String testsStatus;

    private Integer testsCoverage;
    private Integer testDuration;
    private Integer codeCoverage;

    private String testTool;
    private String pipelineStatus;
    private Integer pipelineDuration;

    // Constructors
    public CDTMetricsDto() {}

    // Getters and Setters
    // You can generate these using your IDE or use Lombok if preferred

    // Optional: toString() for logging/debugging
    @Override
    public String toString() {
        return "CDTMetricsDto{" +
                "buildId=" + buildId +
                ", artifactId=" + artifactId +
                ", actionType=" + actionType +
                ", envLevel=" + envLevel +
                ", cdDate=" + cdDate +
                ", ctDate=" + ctDate +
                ", startedBy='" + startedBy + '\'' +
                ", approver='" + approver + '\'' +
                ", deploymentStatus='" + deploymentStatus + '\'' +
                ", totalTests='" + totalTests + '\'' +
                ", passedTests='" + passedTests + '\'' +
                ", failedTests='" + failedTests + '\'' +
                ", notrunTests='" + notrunTests + '\'' +
                ", testsStatus='" + testsStatus + '\'' +
                ", testsCoverage=" + testsCoverage +
                ", testDuration=" + testDuration +
                ", codeCoverage=" + codeCoverage +
                ", testTool='" + testTool + '\'' +
                ", pipelineStatus='" + pipelineStatus + '\'' +
                ", pipelineDuration=" + pipelineDuration +
                '}';
    }

	public String getBuildId() {
		return buildId;
	}

	public void setBuildId(String buildId) {
		this.buildId = buildId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getEnvLevel() {
		return envLevel;
	}

	public void setEnvLevel(String envLevel) {
		this.envLevel = envLevel;
	}

	public OffsetDateTime getCdDate() {
		return cdDate;
	}

	public void setCdDate(OffsetDateTime cdDate) {
		this.cdDate = cdDate;
	}

	public OffsetDateTime getCtDate() {
		return ctDate;
	}

	public void setCtDate(OffsetDateTime ctDate) {
		this.ctDate = ctDate;
	}

	public String getStartedBy() {
		return startedBy;
	}

	public void setStartedBy(String startedBy) {
		this.startedBy = startedBy;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getDeploymentStatus() {
		return deploymentStatus;
	}

	public void setDeploymentStatus(String deploymentStatus) {
		this.deploymentStatus = deploymentStatus;
	}

	public Integer getTotalTests() {
		return totalTests;
	}

	public void setTotalTests(Integer totalTests) {
		this.totalTests = totalTests;
	}

	public Integer getPassedTests() {
		return passedTests;
	}

	public void setPassedTests(Integer passedTests) {
		this.passedTests = passedTests;
	}

	public Integer getFailedTests() {
		return failedTests;
	}

	public void setFailedTests(Integer failedTests) {
		this.failedTests = failedTests;
	}

	public Integer getNotrunTests() {
		return notrunTests;
	}

	public void setNotrunTests(Integer notrunTests) {
		this.notrunTests = notrunTests;
	}

	public String getTestsStatus() {
		return testsStatus;
	}

	public void setTestsStatus(String testsStatus) {
		this.testsStatus = testsStatus;
	}

	public Integer getTestsCoverage() {
		return testsCoverage;
	}

	public void setTestsCoverage(Integer testsCoverage) {
		this.testsCoverage = testsCoverage;
	}

	public Integer getTestDuration() {
		return testDuration;
	}

	public void setTestDuration(Integer testDuration) {
		this.testDuration = testDuration;
	}

	public Integer getCodeCoverage() {
		return codeCoverage;
	}

	public void setCodeCoverage(Integer codeCoverage) {
		this.codeCoverage = codeCoverage;
	}

	public String getTestTool() {
		return testTool;
	}

	public void setTestTool(String testTool) {
		this.testTool = testTool;
	}

	public String getPipelineStatus() {
		return pipelineStatus;
	}

	public void setPipelineStatus(String pipelineStatus) {
		this.pipelineStatus = pipelineStatus;
	}

	public Integer getPipelineDuration() {
		return pipelineDuration;
	}

	public void setPipelineDuration(Integer pipelineDuration) {
		this.pipelineDuration = pipelineDuration;
	}
}
