package com.sample.service;

import com.sample.model.CIMetricsVo;
import com.sample.adapter.Vo2DtoConverter;
import com.sample.dto.CDTMetricsDto;
import com.sample.dto.CIMetricsDto;
import com.sample.model.CDTMetricsVo;
import com.sample.repository.CIMetricsRepository;
import com.sample.repository.CDTMetricsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BuildService {

    @Autowired
    private CIMetricsRepository ciRepo;

    @Autowired
    private CDTMetricsRepository cdRepo;

    public void addCI(CIMetricsVo ci) {
        ciRepo.save(ci);
    }

    public void addCD(CDTMetricsVo cd) {
        cdRepo.save(cd);
    }

    public void updateCD(CDTMetricsVo cd) {
        cdRepo.save(cd);
    }

    public void deleteCD(String buildId) {
        cdRepo.deleteById(buildId);
    }
    
    public CDTMetricsDto findCDbyId(String artifactId) {
        return Vo2DtoConverter.toDto(cdRepo.findLatestByArtifactId(artifactId));
    }
    
    public CIMetricsDto findCIbyId(String artifactId) {
        return Vo2DtoConverter.toDto(ciRepo.findByArtifactId(artifactId));
    }
}
