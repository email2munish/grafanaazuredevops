package com.sample.common;

public class Constants {
	
	public static final String INBOUD_MESSAGE_QUEUE = "inbound_queue";
	public static final String OUTBOUD_MESSAGE_QUEUE = "outbound_queue";
	public static final String FAILURE_MESSAGE_QUEUE = "failure_queue";
	public static final String START_OF_METHOD = " Method starts ";
	public static final String END_OF_METHOD = " Method ends ";
	public static final String METHOD_EDTMLMASSSERVICE = "callEdtMaaSService";
	public static final String METHOD_SERVICE = "MicroServiceCall";
	
	public static final int EDT_SYSTEM_ER_CODE = 900;
	public static final String EDT_SYSTEM_ER_MSG = "Processing Error";
}