/*******************************************************************************
 * Copyright: CopyRight 2017 FedEx Corporation All Rights Reserved 
 * Application Name: RpsOrchestrator 
 * File Name: RpsOrchestratorException.java 
 *  
 * Revision: 1.0
 * Author: f5181813
 * Date: 11/08/2017
 ******************************************************************************/
package com.sample.common;

import java.util.Vector;

/**
 * The exception class used for all errors that occur in TradeXpress processing
 * and that are returned by a TradeOne RpsOrchestratorService.
 */
public class DashBoardException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The TradeXpress error number.
	 */
	Integer errorNumber = null;

	String errorCode = null;

	/**
	 * The arguments used in the error message.
	 */
	Vector errorArgs = null;

	/**
	 * The error message.
	 */
	String errorMsg = null;

	public DashBoardException(DashBoardException txe) {
		if (txe != null) {
			setErrorNumber(txe.getErrorNumber());
			setErrorMsg(txe.getErrorMsg());
			setArguments(txe.getArguments());
		}
	}

	/**
	 * Constructor. Initializes the error number and error message attributes,
	 * creates the error arguments attribute, and inserts the error message
	 * String into the first argument.
	 */
	public DashBoardException(int errNumber, String errMessage) {
		this.errorNumber = new Integer(errNumber);
		this.errorMsg = errMessage; // to handle xml
		addArgument(errMessage);
	}

	/**
	 * Constructor. Initializes the error number and error arguments attributes.
	 * If arguments are not null, flattens all the arguments into 1 String to
	 * initialize the error message attribute.
	 */
	public DashBoardException(int errNumber, Vector errArgs) {
		this.errorNumber = new Integer(errNumber);
		this.errorArgs = errArgs;
		if (errArgs != null) {
			this.errorMsg = errArgs.toString(); // to handle xml
		}
	}

	/**
	 * Constructor. Initializes the error code and error message attributes.
	 */
	public DashBoardException(String errorCode, String errMessage) {
		this.errorCode = errorCode;
		this.errorMsg = errMessage;
	}

	/**
	 * Constructor. Sets the error number attribute.
	 */
	public DashBoardException(int errNumber) {
		this.errorNumber = new Integer(errNumber);
	}

	/**
	 * Gets the error number attribute.
	 */
	public Integer getErrorNumber() {
		return this.errorNumber;
	}

	/**
	 * Sets the error number attributes.
	 */
	public void setErrorNumber(Integer value) {
		this.errorNumber = value;
	}

	/**
	 * Gets the error arguments attribute.
	 */
	public Vector getArguments() {
		return this.errorArgs;
	}

	/**
	 * Sets the error arguments attribute.
	 */
	public void setArguments(Vector errArgs) {
		this.errorArgs = errArgs;
	}

	/**
	 * Adds a new string to the end of the error arguments attribute, and resets
	 * the error message attribute to be the new argument only.
	 */
	
	public void addArgument(String arg) {
		if (this.errorArgs == null) {
			this.errorArgs = new Vector();
		}
		this.errorArgs.add(arg);
		this.errorMsg = arg; // to handle xml
	}

	/**
	 * Gets the error message attribute.
	 */
	public String getErrorMsg() {
		return this.errorMsg;
	}

	/**
	 * Gets the error message attribute.
	 */
	public void setErrorMsg(String errMessage) {
		this.errorMsg = errMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}