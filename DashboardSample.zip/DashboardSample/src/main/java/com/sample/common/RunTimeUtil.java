package com.sample.common;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RunTimeUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RunTimeUtil.class);
	
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd:hhmmss-S");
	
	SecureRandom secureRandom = new SecureRandom();
	
	public void logRunTimeInfo(Runtime runtime,long startFreeHeapMemory, long startTime, String callingMethod) {
		long endTime = System.nanoTime();
		long consumedHeapMemory = runtime.freeMemory();
		long elapsedTime = endTime - startTime;
		long elapsedTimeInMS = TimeUnit.MILLISECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);
		double changePercentageInHeapMemory = ((startFreeHeapMemory - consumedHeapMemory) * 100) / startFreeHeapMemory;
		LOGGER.info("Heap Memory Start= " + startFreeHeapMemory + "Change in heap memory % : "
				+ changePercentageInHeapMemory + " Time takenby "+ callingMethod+ ": " + elapsedTimeInMS);
	}
	
	public long logRunTimeInfo(long startTime, String callingMethod) {
		long endTime = System.nanoTime();
		long elapsedTime = endTime - startTime;
		long elapsedTimeInMS = TimeUnit.MILLISECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);
		LOGGER.info(" Time taken by "+ callingMethod+": " + elapsedTimeInMS);
		return elapsedTimeInMS;
	}
	
	public String createNDCMessage()
	{
		int randomNumber = secureRandom.nextInt(1000000);
		String conversationId = Integer.toString(randomNumber);
		String time = simpleDateFormat.format(new Date());
		
		String internalTxnId = new StringBuilder().append("Convid-").append(conversationId)
				.append("-").append(time).toString();

		//LOGGER.info("internalTxnId:: " + internalTxnId);
		return internalTxnId;
	}

	public String createNDCMessage(String request)
	{
		int randomNumber = secureRandom.nextInt(1000000);
		String conversationId = Integer.toString(randomNumber);
		String time = simpleDateFormat.format(new Date());
		
		String internalTxnId = new StringBuilder().append("Convid-").append(conversationId)
				.append("-").append(time).toString();

		//LOGGER.info("internalTxnId:: " + internalTxnId);
		return internalTxnId;
	}
}
