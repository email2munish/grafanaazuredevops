package com.sample.model;


import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CI_Metrics")
public class CIMetricsVo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4843375875973750482L;

	@Id
    @Column(name = "build_id")
    private String buildId;

    @Column(name = "service_Name" , nullable = false)
	private String serviceName;


    @Column(name = "branch_Name" , nullable = false)
	private String branchName;

    @Column(name = "group_Name", nullable = false)
    private String groupName;

    @Column(name = "area_Name", nullable = false)
    private String areaName;

    @Column(name = "artifact_id", nullable = false)
    private String artifactId;

    @Column(name = "action_Type", nullable = false)
    private String actionType;

    @Column(name = "ci_date", nullable = false)
    private OffsetDateTime ciDate;

    @Column(name = "sqr_issues")
    private Integer sqrIssues;

    @Column(name = "new_sqr_issues")
    private Integer newSqrIssues;

    @Column(name = "sqr_rating")
    private String sqrRating;

    @Column(name = "new_sqr_rating")
    private String newSqrRating;

    @Column(name = "sqr_remediation_effort")
    private String sqrRemediationEffort;

    @Column(name = "new_sqr_remediation_effort")
    private String newSqrRemediationEffort;

    @Column(name = "sqm_issues")
    private Integer sqmIssues;

    @Column(name = "new_sqm_issues")
    private Integer newSqmIssues;

    @Column(name = "sqm_remediation_effort")
    private String sqmRemediationEffort;

    @Column(name = "new_sqm_remediation_effort")
    private String newSqmRemediationEffort;

    @Column(name = "sqm_debt_ratio")
    private String sqmDebtRatio;

    @Column(name = "new_sqm_debt_ratio")
    private String newSqmDebtRatio;

    @Column(name = "sqm_rating")
    private String sqmRating;

    @Column(name = "new_sqm_rating")
    private String newSqmRating;

    @Column(name = "coverage")
    private Integer coverage;

    @Column(name = "new_coverage")
    private Integer newCoverage;

    @Column(name = "lines_to_cover")
    private Integer linesToCover;

    @Column(name = "new_lines_to_cover")
    private Integer newLinesToCover;

    @Column(name = "uncovered_lines")
    private Integer uncoveredLines;

    @Column(name = "new_uncovered_lines")
    private Integer newUncoveredLines;

    @Column(name = "tests")
    private Integer tests;

    @Column(name = "test_errors")
    private Integer testErrors;

    @Column(name = "test_failures")
    private Integer testFailures;

    @Column(name = "skipped_tests")
    private Integer skippedTests;

    @Column(name = "test_execution_time")
    private Integer testExecutionTime;

    @Column(name = "test_success_density")
    private Integer testSuccessDensity;

    @Column(name = "duplicated_lines_density")
    private Integer duplicatedLinesDensity;

    @Column(name = "new_duplicated_lines_density")
    private Integer newDuplicatedLinesDensity;

    @Column(name = "duplicated_lines")
    private Integer duplicatedLines;

    @Column(name = "duplicated_blocks")
    private Integer duplicatedBlocks;

    @Column(name = "new_duplicated_blocks")
    private Integer newDuplicatedBlocks;

    @Column(name = "duplicated_files")
    private Integer duplicatedFiles;

    @Column(name = "new_lines")
    private Integer newLines;

    @Column(name = "ncloc")
    private Integer ncloc;

    @Column(name = "lines")
    private Integer lines;

    @Column(name = "statements")
    private Integer statements;

    @Column(name = "functions")
    private Integer functions;

    @Column(name = "classes")
    private Integer classes;

    @Column(name = "files")
    private Integer files;

    @Column(name = "comment_lines")
    private Integer commentLines;

    @Column(name = "comment_lines_density")
    private Integer commentLinesDensity;

    @Column(name = "complexity")
    private Integer complexity;

    @Column(name = "cognitive_complexity")
    private Integer cognitiveComplexity;

    @Column(name = "violations")
    private Integer violations;

    @Column(name = "new_violations")
    private Integer newViolations;

    @Column(name = "open_issues")
    private Integer openIssues;

    @Column(name = "accepted_issues")
    private Integer acceptedIssues;

    @Column(name = "false_positive_issues")
    private Integer falsePositiveIssues;

    @Column(name = "software_quality_blocker_issues")
    private Integer softwareQualityBlockerIssues;

    @Column(name = "software_quality_high_issues")
    private Integer softwareQualityHighIssues;

    @Column(name = "software_quality_medium_issues")
    private Integer softwareQualityMediumIssues;

    @Column(name = "software_quality_low_issues")
    private Integer softwareQualityLowIssues;

    @Column(name = "sast_issue_low")
    private Integer sastIssueLow;

    @Column(name = "sast_issue_medium")
    private Integer sastIssueMedium;

    @Column(name = "sast_issue_high")
    private Integer sastIssueHigh;

    @Column(name = "sast_issue_critical")
    private Integer sastIssueCritical;

    @Column(name = "sast_issue_blocker")
    private Integer sastIssueBlocker;

    @Column(name = "sast_issue_total")
    private Integer sastIssueTotal;

    @Column(name = "sca_issue_low")
    private Integer scaIssueLow;

    @Column(name = "sca_issue_medium")
    private Integer scaIssueMedium;

    @Column(name = "sca_issue_high")
    private Integer scaIssueHigh;

    @Column(name = "sca_issue_critical")
    private Integer scaIssueCritical;

    @Column(name = "sca_issue_blocker")
    private Integer scaIssueBlocker;

    @Column(name = "sca_issue_total")
    private Integer scaIssueTotal;

    @Column(name = "twist_vulnerabilities_low")
    private Integer twistVulnerabilitiesLow;

    @Column(name = "twist_vulnerabilities_medium")
    private Integer twistVulnerabilitiesMedium;

    @Column(name = "twist_vulnerabilities_high")
    private Integer twistVulnerabilitiesHigh;

    @Column(name = "twist_vulnerabilities_critical")
    private Integer twistVulnerabilitiesCritical;

    @Column(name = "twist_vulnerabilities_blocker")
    private Integer twistVulnerabilitiesBlocker;

    @Column(name = "twist_vulnerabilities_total")
    private Integer twistVulnerabilitiesTotal;

    @Column(name = "twist_compliance_low")
    private Integer twistComplianceLow;

    @Column(name = "twist_compliance_medium")
    private Integer twistComplianceMedium;

    @Column(name = "twist_compliance_high")
    private Integer twistComplianceHigh;

    @Column(name = "twist_compliance_critical")
    private Integer twistComplianceCritical;

    @Column(name = "twist_compliance_blocker")
    private Integer twistComplianceBlocker;

    @Column(name = "twist_compliance_total")
    private Integer twistComplianceTotal;
    
    @Column(name = "pipeline_status")
    private String pipelineStatus;

    public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	@Column(name = "pipeline_duration")
    private Integer pipelineDuration;

	public String getBuildId() {
		return buildId;
	}

	public void setBuildId(String buildId) {
		this.buildId = buildId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public OffsetDateTime getCiDate() {
		return ciDate;
	}

	public void setCiDate(OffsetDateTime ciDate) {
		this.ciDate = ciDate;
	}

	public Integer getSqrIssues() {
		return sqrIssues;
	}

	public void setSqrIssues(Integer sqrIssues) {
		this.sqrIssues = sqrIssues;
	}

	public Integer getNewSqrIssues() {
		return newSqrIssues;
	}

	public void setNewSqrIssues(Integer newSqrIssues) {
		this.newSqrIssues = newSqrIssues;
	}

	public String getSqrRating() {
		return sqrRating;
	}

	public void setSqrRating(String sqrRating) {
		this.sqrRating = sqrRating;
	}

	public String getNewSqrRating() {
		return newSqrRating;
	}

	public void setNewSqrRating(String newSqrRating) {
		this.newSqrRating = newSqrRating;
	}

	public String getSqrRemediationEffort() {
		return sqrRemediationEffort;
	}

	public void setSqrRemediationEffort(String sqrRemediationEffort) {
		this.sqrRemediationEffort = sqrRemediationEffort;
	}

	public String getNewSqrRemediationEffort() {
		return newSqrRemediationEffort;
	}

	public void setNewSqrRemediationEffort(String newSqrRemediationEffort) {
		this.newSqrRemediationEffort = newSqrRemediationEffort;
	}

	public Integer getSqmIssues() {
		return sqmIssues;
	}

	public void setSqmIssues(Integer sqmIssues) {
		this.sqmIssues = sqmIssues;
	}

	public Integer getNewSqmIssues() {
		return newSqmIssues;
	}

	public void setNewSqmIssues(Integer newSqmIssues) {
		this.newSqmIssues = newSqmIssues;
	}

	public String getSqmRemediationEffort() {
		return sqmRemediationEffort;
	}

	public void setSqmRemediationEffort(String sqmRemediationEffort) {
		this.sqmRemediationEffort = sqmRemediationEffort;
	}

	public String getNewSqmRemediationEffort() {
		return newSqmRemediationEffort;
	}

	public void setNewSqmRemediationEffort(String newSqmRemediationEffort) {
		this.newSqmRemediationEffort = newSqmRemediationEffort;
	}

	public String getSqmDebtRatio() {
		return sqmDebtRatio;
	}

	public void setSqmDebtRatio(String sqmDebtRatio) {
		this.sqmDebtRatio = sqmDebtRatio;
	}

	public String getNewSqmDebtRatio() {
		return newSqmDebtRatio;
	}

	public void setNewSqmDebtRatio(String newSqmDebtRatio) {
		this.newSqmDebtRatio = newSqmDebtRatio;
	}

	public String getSqmRating() {
		return sqmRating;
	}

	public void setSqmRating(String sqmRating) {
		this.sqmRating = sqmRating;
	}

	public String getNewSqmRating() {
		return newSqmRating;
	}

	public void setNewSqmRating(String newSqmRating) {
		this.newSqmRating = newSqmRating;
	}

	public Integer getCoverage() {
		return coverage;
	}

	public void setCoverage(Integer coverage) {
		this.coverage = coverage;
	}

	public Integer getNewCoverage() {
		return newCoverage;
	}

	public void setNewCoverage(Integer newCoverage) {
		this.newCoverage = newCoverage;
	}

	public Integer getLinesToCover() {
		return linesToCover;
	}

	public void setLinesToCover(Integer linesToCover) {
		this.linesToCover = linesToCover;
	}

	public Integer getNewLinesToCover() {
		return newLinesToCover;
	}

	public void setNewLinesToCover(Integer newLinesToCover) {
		this.newLinesToCover = newLinesToCover;
	}

	public Integer getUncoveredLines() {
		return uncoveredLines;
	}

	public void setUncoveredLines(Integer uncoveredLines) {
		this.uncoveredLines = uncoveredLines;
	}

	public Integer getNewUncoveredLines() {
		return newUncoveredLines;
	}

	public void setNewUncoveredLines(Integer newUncoveredLines) {
		this.newUncoveredLines = newUncoveredLines;
	}

	public Integer getTests() {
		return tests;
	}

	public void setTests(Integer tests) {
		this.tests = tests;
	}

	public Integer getTestErrors() {
		return testErrors;
	}

	public void setTestErrors(Integer testErrors) {
		this.testErrors = testErrors;
	}

	public Integer getTestFailures() {
		return testFailures;
	}

	public void setTestFailures(Integer testFailures) {
		this.testFailures = testFailures;
	}

	public Integer getSkippedTests() {
		return skippedTests;
	}

	public void setSkippedTests(Integer skippedTests) {
		this.skippedTests = skippedTests;
	}

	public Integer getTestExecutionTime() {
		return testExecutionTime;
	}

	public void setTestExecutionTime(Integer testExecutionTime) {
		this.testExecutionTime = testExecutionTime;
	}

	public Integer getTestSuccessDensity() {
		return testSuccessDensity;
	}

	public void setTestSuccessDensity(Integer testSuccessDensity) {
		this.testSuccessDensity = testSuccessDensity;
	}

	public Integer getDuplicatedLinesDensity() {
		return duplicatedLinesDensity;
	}

	public void setDuplicatedLinesDensity(Integer duplicatedLinesDensity) {
		this.duplicatedLinesDensity = duplicatedLinesDensity;
	}

	public Integer getNewDuplicatedLinesDensity() {
		return newDuplicatedLinesDensity;
	}

	public void setNewDuplicatedLinesDensity(Integer newDuplicatedLinesDensity) {
		this.newDuplicatedLinesDensity = newDuplicatedLinesDensity;
	}

	public Integer getDuplicatedLines() {
		return duplicatedLines;
	}

	public void setDuplicatedLines(Integer duplicatedLines) {
		this.duplicatedLines = duplicatedLines;
	}

	public Integer getDuplicatedBlocks() {
		return duplicatedBlocks;
	}

	public void setDuplicatedBlocks(Integer duplicatedBlocks) {
		this.duplicatedBlocks = duplicatedBlocks;
	}

	public Integer getNewDuplicatedBlocks() {
		return newDuplicatedBlocks;
	}

	public void setNewDuplicatedBlocks(Integer newDuplicatedBlocks) {
		this.newDuplicatedBlocks = newDuplicatedBlocks;
	}

	public Integer getDuplicatedFiles() {
		return duplicatedFiles;
	}

	public void setDuplicatedFiles(Integer duplicatedFiles) {
		this.duplicatedFiles = duplicatedFiles;
	}

	public Integer getNewLines() {
		return newLines;
	}

	public void setNewLines(Integer newLines) {
		this.newLines = newLines;
	}

	public Integer getNcloc() {
		return ncloc;
	}

	public void setNcloc(Integer ncloc) {
		this.ncloc = ncloc;
	}

	public Integer getLines() {
		return lines;
	}

	public void setLines(Integer lines) {
		this.lines = lines;
	}

	public Integer getStatements() {
		return statements;
	}

	public void setStatements(Integer statements) {
		this.statements = statements;
	}

	public Integer getFunctions() {
		return functions;
	}

	public void setFunctions(Integer functions) {
		this.functions = functions;
	}

	public Integer getClasses() {
		return classes;
	}

	public void setClasses(Integer classes) {
		this.classes = classes;
	}

	public Integer getFiles() {
		return files;
	}

	public void setFiles(Integer files) {
		this.files = files;
	}

	public Integer getCommentLines() {
		return commentLines;
	}

	public void setCommentLines(Integer commentLines) {
		this.commentLines = commentLines;
	}

	public Integer getCommentLinesDensity() {
		return commentLinesDensity;
	}

	public void setCommentLinesDensity(Integer commentLinesDensity) {
		this.commentLinesDensity = commentLinesDensity;
	}

	public Integer getComplexity() {
		return complexity;
	}

	public void setComplexity(Integer complexity) {
		this.complexity = complexity;
	}

	public Integer getCognitiveComplexity() {
		return cognitiveComplexity;
	}

	public void setCognitiveComplexity(Integer cognitiveComplexity) {
		this.cognitiveComplexity = cognitiveComplexity;
	}

	public Integer getViolations() {
		return violations;
	}

	public void setViolations(Integer violations) {
		this.violations = violations;
	}

	public Integer getNewViolations() {
		return newViolations;
	}

	public void setNewViolations(Integer newViolations) {
		this.newViolations = newViolations;
	}

	public Integer getOpenIssues() {
		return openIssues;
	}

	public void setOpenIssues(Integer openIssues) {
		this.openIssues = openIssues;
	}

	public Integer getAcceptedIssues() {
		return acceptedIssues;
	}

	public void setAcceptedIssues(Integer acceptedIssues) {
		this.acceptedIssues = acceptedIssues;
	}

	public Integer getFalsePositiveIssues() {
		return falsePositiveIssues;
	}

	public void setFalsePositiveIssues(Integer falsePositiveIssues) {
		this.falsePositiveIssues = falsePositiveIssues;
	}

	public Integer getSoftwareQualityBlockerIssues() {
		return softwareQualityBlockerIssues;
	}

	public void setSoftwareQualityBlockerIssues(Integer softwareQualityBlockerIssues) {
		this.softwareQualityBlockerIssues = softwareQualityBlockerIssues;
	}

	public Integer getSoftwareQualityHighIssues() {
		return softwareQualityHighIssues;
	}

	public void setSoftwareQualityHighIssues(Integer softwareQualityHighIssues) {
		this.softwareQualityHighIssues = softwareQualityHighIssues;
	}

	public Integer getSoftwareQualityMediumIssues() {
		return softwareQualityMediumIssues;
	}

	public void setSoftwareQualityMediumIssues(Integer softwareQualityMediumIssues) {
		this.softwareQualityMediumIssues = softwareQualityMediumIssues;
	}

	public Integer getSoftwareQualityLowIssues() {
		return softwareQualityLowIssues;
	}

	public void setSoftwareQualityLowIssues(Integer softwareQualityLowIssues) {
		this.softwareQualityLowIssues = softwareQualityLowIssues;
	}

	public Integer getSastIssueLow() {
		return sastIssueLow;
	}

	public void setSastIssueLow(Integer sastIssueLow) {
		this.sastIssueLow = sastIssueLow;
	}

	public Integer getSastIssueMedium() {
		return sastIssueMedium;
	}

	public void setSastIssueMedium(Integer sastIssueMedium) {
		this.sastIssueMedium = sastIssueMedium;
	}

	public Integer getSastIssueHigh() {
		return sastIssueHigh;
	}

	public void setSastIssueHigh(Integer sastIssueHigh) {
		this.sastIssueHigh = sastIssueHigh;
	}

	public Integer getSastIssueCritical() {
		return sastIssueCritical;
	}

	public void setSastIssueCritical(Integer sastIssueCritical) {
		this.sastIssueCritical = sastIssueCritical;
	}

	public Integer getSastIssueBlocker() {
		return sastIssueBlocker;
	}

	public void setSastIssueBlocker(Integer sastIssueBlocker) {
		this.sastIssueBlocker = sastIssueBlocker;
	}

	public Integer getSastIssueTotal() {
		return sastIssueTotal;
	}

	public void setSastIssueTotal(Integer sastIssueTotal) {
		this.sastIssueTotal = sastIssueTotal;
	}

	public Integer getScaIssueLow() {
		return scaIssueLow;
	}

	public void setScaIssueLow(Integer scaIssueLow) {
		this.scaIssueLow = scaIssueLow;
	}

	public Integer getScaIssueMedium() {
		return scaIssueMedium;
	}

	public void setScaIssueMedium(Integer scaIssueMedium) {
		this.scaIssueMedium = scaIssueMedium;
	}

	public Integer getScaIssueHigh() {
		return scaIssueHigh;
	}

	public void setScaIssueHigh(Integer scaIssueHigh) {
		this.scaIssueHigh = scaIssueHigh;
	}

	public Integer getScaIssueCritical() {
		return scaIssueCritical;
	}

	public void setScaIssueCritical(Integer scaIssueCritical) {
		this.scaIssueCritical = scaIssueCritical;
	}

	public Integer getScaIssueBlocker() {
		return scaIssueBlocker;
	}

	public void setScaIssueBlocker(Integer scaIssueBlocker) {
		this.scaIssueBlocker = scaIssueBlocker;
	}

	public Integer getScaIssueTotal() {
		return scaIssueTotal;
	}

	public void setScaIssueTotal(Integer scaIssueTotal) {
		this.scaIssueTotal = scaIssueTotal;
	}

	public Integer getTwistVulnerabilitiesLow() {
		return twistVulnerabilitiesLow;
	}

	public void setTwistVulnerabilitiesLow(Integer twistVulnerabilitiesLow) {
		this.twistVulnerabilitiesLow = twistVulnerabilitiesLow;
	}

	public Integer getTwistVulnerabilitiesMedium() {
		return twistVulnerabilitiesMedium;
	}

	public void setTwistVulnerabilitiesMedium(Integer twistVulnerabilitiesMedium) {
		this.twistVulnerabilitiesMedium = twistVulnerabilitiesMedium;
	}

	public Integer getTwistVulnerabilitiesHigh() {
		return twistVulnerabilitiesHigh;
	}

	public void setTwistVulnerabilitiesHigh(Integer twistVulnerabilitiesHigh) {
		this.twistVulnerabilitiesHigh = twistVulnerabilitiesHigh;
	}

	public Integer getTwistVulnerabilitiesCritical() {
		return twistVulnerabilitiesCritical;
	}

	public void setTwistVulnerabilitiesCritical(Integer twistVulnerabilitiesCritical) {
		this.twistVulnerabilitiesCritical = twistVulnerabilitiesCritical;
	}

	public Integer getTwistVulnerabilitiesBlocker() {
		return twistVulnerabilitiesBlocker;
	}

	public void setTwistVulnerabilitiesBlocker(Integer twistVulnerabilitiesBlocker) {
		this.twistVulnerabilitiesBlocker = twistVulnerabilitiesBlocker;
	}

	public Integer getTwistVulnerabilitiesTotal() {
		return twistVulnerabilitiesTotal;
	}

	public void setTwistVulnerabilitiesTotal(Integer twistVulnerabilitiesTotal) {
		this.twistVulnerabilitiesTotal = twistVulnerabilitiesTotal;
	}

	public Integer getTwistComplianceLow() {
		return twistComplianceLow;
	}

	public void setTwistComplianceLow(Integer twistComplianceLow) {
		this.twistComplianceLow = twistComplianceLow;
	}

	public Integer getTwistComplianceMedium() {
		return twistComplianceMedium;
	}

	public void setTwistComplianceMedium(Integer twistComplianceMedium) {
		this.twistComplianceMedium = twistComplianceMedium;
	}

	public Integer getTwistComplianceHigh() {
		return twistComplianceHigh;
	}

	public void setTwistComplianceHigh(Integer twistComplianceHigh) {
		this.twistComplianceHigh = twistComplianceHigh;
	}

	public Integer getTwistComplianceCritical() {
		return twistComplianceCritical;
	}

	public void setTwistComplianceCritical(Integer twistComplianceCritical) {
		this.twistComplianceCritical = twistComplianceCritical;
	}

	public Integer getTwistComplianceBlocker() {
		return twistComplianceBlocker;
	}

	public void setTwistComplianceBlocker(Integer twistComplianceBlocker) {
		this.twistComplianceBlocker = twistComplianceBlocker;
	}

	public Integer getTwistComplianceTotal() {
		return twistComplianceTotal;
	}

	public void setTwistComplianceTotal(Integer twistComplianceTotal) {
		this.twistComplianceTotal = twistComplianceTotal;
	}

	public String getPipelineStatus() {
		return pipelineStatus;
	}

	public void setPipelineStatus(String pipelineStatus) {
		this.pipelineStatus = pipelineStatus;
	}

	public Integer getPipelineDuration() {
		return pipelineDuration;
	}

	public void setPipelineDuration(Integer pipelineDuration) {
		this.pipelineDuration = pipelineDuration;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}