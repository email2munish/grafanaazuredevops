package com.sample.model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;

@Entity
@Table(name = "CDT_Metrics")
public class CDTMetricsVo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 115576797413823066L;

	@Id
    @Column(name = "build_id")
    private String buildId;

    @Column(name = "artifact_id", nullable = false)
    private String artifactId;

    @Column(name = "action_Type", nullable = false)
    private String actionType;

    @Column(name = "env_level")
    private String envLevel;

    @Column(name = "cd_date")
    private OffsetDateTime cdDate;

    @Column(name = "ct_date")
    private OffsetDateTime ctDate;

    @Column(name = "started_by")
    private String startedBy;

    @Column(name = "approver")
    private String approver;

    @Column(name = "deployment_status")
    private String deploymentStatus;

    @Column(name = "total_tests")
    private Integer totalTests;

    @Column(name = "passed_tests")
    private Integer passedTests;

    @Column(name = "failed_tests")
    private Integer failedTests;

    @Column(name = "notrun_tests")
    private Integer notrunTests;

    @Column(name = "tests_status")
    private String testsStatus;

    @Column(name = "tests_coverage")
    private Integer testsCoverage;

    @Column(name = "test_duration")
    private Integer testDuration;

    @Column(name = "code_coverage")
    private Integer codeCoverage;

    @Column(name = "test_tool")
    private String testTool;

    @Column(name = "pipeline_status")
    private String pipelineStatus;

    @Column(name = "pipeline_duration")
    private Integer pipelineDuration;

	public String getBuildId() {
		return buildId;
	}

	public void setBuildId(String buildId) {
		this.buildId = buildId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getEnvLevel() {
		return envLevel;
	}

	public void setEnvLevel(String envLevel) {
		this.envLevel = envLevel;
	}

	public OffsetDateTime getCdDate() {
		return cdDate;
	}

	public void setCdDate(OffsetDateTime cdDate) {
		this.cdDate = cdDate;
	}

	public OffsetDateTime getCtDate() {
		return ctDate;
	}

	public void setCtDate(OffsetDateTime ctDate) {
		this.ctDate = ctDate;
	}

	public String getStartedBy() {
		return startedBy;
	}

	public void setStartedBy(String startedBy) {
		this.startedBy = startedBy;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getDeploymentStatus() {
		return deploymentStatus;
	}

	public void setDeploymentStatus(String deploymentStatus) {
		this.deploymentStatus = deploymentStatus;
	}

	public Integer getTotalTests() {
		return totalTests;
	}

	public void setTotalTests(Integer totalTests) {
		this.totalTests = totalTests;
	}

	public Integer getPassedTests() {
		return passedTests;
	}

	public void setPassedTests(Integer passedTests) {
		this.passedTests = passedTests;
	}

	public Integer getFailedTests() {
		return failedTests;
	}

	public void setFailedTests(Integer failedTests) {
		this.failedTests = failedTests;
	}

	public Integer getNotrunTests() {
		return notrunTests;
	}

	public void setNotrunTests(Integer notrunTests) {
		this.notrunTests = notrunTests;
	}

	public String getTestsStatus() {
		return testsStatus;
	}

	public void setTestsStatus(String testsStatus) {
		this.testsStatus = testsStatus;
	}

	public Integer getTestsCoverage() {
		return testsCoverage;
	}

	public void setTestsCoverage(Integer testsCoverage) {
		this.testsCoverage = testsCoverage;
	}

	public Integer getTestDuration() {
		return testDuration;
	}

	public void setTestDuration(Integer testDuration) {
		this.testDuration = testDuration;
	}

	public Integer getCodeCoverage() {
		return codeCoverage;
	}

	public void setCodeCoverage(Integer codeCoverage) {
		this.codeCoverage = codeCoverage;
	}

	public String getTestTool() {
		return testTool;
	}

	public void setTestTool(String testTool) {
		this.testTool = testTool;
	}

	public String getPipelineStatus() {
		return pipelineStatus;
	}

	public void setPipelineStatus(String pipelineStatus) {
		this.pipelineStatus = pipelineStatus;
	}

	public Integer getPipelineDuration() {
		return pipelineDuration;
	}

	public void setPipelineDuration(Integer pipelineDuration) {
		this.pipelineDuration = pipelineDuration;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
