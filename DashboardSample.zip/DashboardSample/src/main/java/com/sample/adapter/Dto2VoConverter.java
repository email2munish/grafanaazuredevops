package com.sample.adapter;

import com.sample.dto.CDTMetricsDto;
import com.sample.dto.CIMetricsDto;
import com.sample.model.CDTMetricsVo;
import com.sample.model.CIMetricsVo;

public class Dto2VoConverter {

    public static CDTMetricsVo toEntity(CDTMetricsDto dto) {
        if (dto == null) return null;

        CDTMetricsVo vo = new CDTMetricsVo();
        vo.setBuildId(dto.getBuildId());
        vo.setArtifactId(dto.getArtifactId());
        vo.setActionType(dto.getActionType());
        vo.setEnvLevel(dto.getEnvLevel());
        vo.setCdDate(dto.getCdDate());
        vo.setCtDate(dto.getCtDate());
        vo.setStartedBy(dto.getStartedBy());
        vo.setApprover(dto.getApprover());
        vo.setDeploymentStatus(dto.getDeploymentStatus());
        vo.setTotalTests(dto.getTotalTests());
        vo.setPassedTests(dto.getPassedTests());
        vo.setFailedTests(dto.getFailedTests());
        vo.setNotrunTests(dto.getNotrunTests());
        vo.setTestsStatus(dto.getTestsStatus());
        vo.setTestsCoverage(dto.getTestsCoverage());
        vo.setTestDuration(dto.getTestDuration());
        vo.setCodeCoverage(dto.getCodeCoverage());
        vo.setTestTool(dto.getTestTool());
        vo.setPipelineStatus(dto.getPipelineStatus());
        vo.setPipelineDuration(dto.getPipelineDuration());
        return vo;
    }

    public static CIMetricsVo toEntity(CIMetricsDto dto) {
        if (dto == null) return null;

        CIMetricsVo vo = new CIMetricsVo();
        vo.setBuildId(dto.getBuildId());
        vo.setServiceName(dto.getServiceName());
        vo.setBranchName(dto.getBranchName());
        vo.setAreaName(dto.getAreaName());
        vo.setGroupName(dto.getGroupName());
        vo.setArtifactId(dto.getArtifactId());
        vo.setActionType(dto.getActionType());
        vo.setCiDate(dto.getCiDate());

        vo.setSqrIssues(dto.getSqrIssues());
        vo.setNewSqrIssues(dto.getNewSqrIssues());
        vo.setSqrRating(dto.getSqrRating());
        vo.setNewSqrRating(dto.getNewSqrRating());
        vo.setSqrRemediationEffort(dto.getSqrRemediationEffort());
        vo.setNewSqrRemediationEffort(dto.getNewSqrRemediationEffort());

        vo.setSqmIssues(dto.getSqmIssues());
        vo.setNewSqmIssues(dto.getNewSqmIssues());
        vo.setSqmRemediationEffort(dto.getSqmRemediationEffort());
        vo.setNewSqmRemediationEffort(dto.getNewSqmRemediationEffort());
        vo.setSqmDebtRatio(dto.getSqmDebtRatio());
        vo.setNewSqmDebtRatio(dto.getNewSqmDebtRatio());
        vo.setSqmRating(dto.getSqmRating());
        vo.setNewSqmRating(dto.getNewSqmRating());

        vo.setCoverage(dto.getCoverage());
        vo.setNewCoverage(dto.getNewCoverage());
        vo.setLinesToCover(dto.getLinesToCover());
        vo.setNewLinesToCover(dto.getNewLinesToCover());
        vo.setUncoveredLines(dto.getUncoveredLines());
        vo.setNewUncoveredLines(dto.getNewUncoveredLines());

        vo.setTests(dto.getTests());
        vo.setTestErrors(dto.getTestErrors());
        vo.setTestFailures(dto.getTestFailures());
        vo.setSkippedTests(dto.getSkippedTests());
        vo.setTestExecutionTime(dto.getTestExecutionTime());
        vo.setTestSuccessDensity(dto.getTestSuccessDensity());

        vo.setDuplicatedLinesDensity(dto.getDuplicatedLinesDensity());
        vo.setNewDuplicatedLinesDensity(dto.getNewDuplicatedLinesDensity());
        vo.setDuplicatedLines(dto.getDuplicatedLines());
        vo.setDuplicatedBlocks(dto.getDuplicatedBlocks());
        vo.setNewDuplicatedBlocks(dto.getNewDuplicatedBlocks());
        vo.setDuplicatedFiles(dto.getDuplicatedFiles());

        vo.setNewLines(dto.getNewLines());
        vo.setNcloc(dto.getNcloc());
        vo.setLines(dto.getLines());
        vo.setStatements(dto.getStatements());
        vo.setFunctions(dto.getFunctions());
        vo.setClasses(dto.getClasses());
        vo.setFiles(dto.getFiles());
        vo.setCommentLines(dto.getCommentLines());
        vo.setCommentLinesDensity(dto.getCommentLinesDensity());

        vo.setComplexity(dto.getComplexity());
        vo.setCognitiveComplexity(dto.getCognitiveComplexity());

        vo.setViolations(dto.getViolations());
        vo.setNewViolations(dto.getNewViolations());
        vo.setOpenIssues(dto.getOpenIssues());
        vo.setAcceptedIssues(dto.getAcceptedIssues());
        vo.setFalsePositiveIssues(dto.getFalsePositiveIssues());
        vo.setSoftwareQualityBlockerIssues(dto.getSoftwareQualityBlockerIssues());
        vo.setSoftwareQualityHighIssues(dto.getSoftwareQualityHighIssues());
        vo.setSoftwareQualityMediumIssues(dto.getSoftwareQualityMediumIssues());
        vo.setSoftwareQualityLowIssues(dto.getSoftwareQualityLowIssues());

        vo.setSastIssueLow(dto.getSastIssueLow());
        vo.setSastIssueMedium(dto.getSastIssueMedium());
        vo.setSastIssueHigh(dto.getSastIssueHigh());
        vo.setSastIssueCritical(dto.getSastIssueCritical());
        vo.setSastIssueBlocker(dto.getSastIssueBlocker());
        vo.setSastIssueTotal(dto.getSastIssueTotal());

        vo.setScaIssueLow(dto.getScaIssueLow());
        vo.setScaIssueMedium(dto.getScaIssueMedium());
        vo.setScaIssueHigh(dto.getScaIssueHigh());
        vo.setScaIssueCritical(dto.getScaIssueCritical());
        vo.setScaIssueBlocker(dto.getScaIssueBlocker());
        vo.setScaIssueTotal(dto.getScaIssueTotal());

        vo.setTwistVulnerabilitiesLow(dto.getTwistVulnerabilitiesLow());
        vo.setTwistVulnerabilitiesMedium(dto.getTwistVulnerabilitiesMedium());
        vo.setTwistVulnerabilitiesHigh(dto.getTwistVulnerabilitiesHigh());
        vo.setTwistVulnerabilitiesCritical(dto.getTwistVulnerabilitiesCritical());
        vo.setTwistVulnerabilitiesBlocker(dto.getTwistVulnerabilitiesBlocker());
        vo.setTwistVulnerabilitiesTotal(dto.getTwistVulnerabilitiesTotal());

        vo.setTwistComplianceLow(dto.getTwistComplianceLow());
        vo.setTwistComplianceMedium(dto.getTwistComplianceMedium());
        vo.setTwistComplianceHigh(dto.getTwistComplianceHigh());
        vo.setTwistComplianceCritical(dto.getTwistComplianceCritical());
        vo.setTwistComplianceBlocker(dto.getTwistComplianceBlocker());
        vo.setTwistComplianceTotal(dto.getTwistComplianceTotal());

        vo.setPipelineStatus(dto.getPipelineStatus());
        vo.setPipelineDuration(dto.getPipelineDuration());

        return vo;
    }
}
