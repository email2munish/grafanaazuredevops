package com.sample.adapter;

import com.sample.dto.CDTMetricsDto;
import com.sample.dto.CIMetricsDto;
import com.sample.model.CDTMetricsVo;
import com.sample.model.CIMetricsVo;

public class Vo2DtoConverter {

    public static CDTMetricsDto toDto(CDTMetricsVo vo) {
        if (vo == null) return null;

        CDTMetricsDto dto = new CDTMetricsDto();
        dto.setBuildId(vo.getBuildId());
        dto.setArtifactId(vo.getArtifactId());
        dto.setActionType(vo.getActionType());
        dto.setEnvLevel(vo.getEnvLevel());
        dto.setCdDate(vo.getCdDate());
        dto.setCtDate(vo.getCtDate());
        dto.setStartedBy(vo.getStartedBy());
        dto.setApprover(vo.getApprover());
        dto.setDeploymentStatus(vo.getDeploymentStatus());
        dto.setTotalTests(vo.getTotalTests());
        dto.setPassedTests(vo.getPassedTests());
        dto.setFailedTests(vo.getFailedTests());
        dto.setNotrunTests(vo.getNotrunTests());
        dto.setTestsStatus(vo.getTestsStatus());
        dto.setTestsCoverage(vo.getTestsCoverage());
        dto.setTestDuration(vo.getTestDuration());
        dto.setCodeCoverage(vo.getCodeCoverage());
        dto.setTestTool(vo.getTestTool());
        dto.setPipelineStatus(vo.getPipelineStatus());
        dto.setPipelineDuration(vo.getPipelineDuration());
        return dto;
    }

    public static CIMetricsDto toDto(CIMetricsVo vo) {
        if (vo == null) return null;

        CIMetricsDto dto = new CIMetricsDto();
        dto.setBuildId(vo.getBuildId());
        dto.setServiceName(vo.getServiceName());
        dto.setBranchName(vo.getBranchName());
        dto.setGroupName(vo.getGroupName());
        dto.setAreaName(vo.getAreaName());
        dto.setArtifactId(vo.getArtifactId());
        dto.setActionType(vo.getActionType());
        dto.setCiDate(vo.getCiDate());

        dto.setSqrIssues(vo.getSqrIssues());
        dto.setNewSqrIssues(vo.getNewSqrIssues());
        dto.setSqrRating(vo.getSqrRating());
        dto.setNewSqrRating(vo.getNewSqrRating());
        dto.setSqrRemediationEffort(vo.getSqrRemediationEffort());
        dto.setNewSqrRemediationEffort(vo.getNewSqrRemediationEffort());

        dto.setSqmIssues(vo.getSqmIssues());
        dto.setNewSqmIssues(vo.getNewSqmIssues());
        dto.setSqmRemediationEffort(vo.getSqmRemediationEffort());
        dto.setNewSqmRemediationEffort(vo.getNewSqmRemediationEffort());
        dto.setSqmDebtRatio(vo.getSqmDebtRatio());
        dto.setNewSqmDebtRatio(vo.getNewSqmDebtRatio());
        dto.setSqmRating(vo.getSqmRating());
        dto.setNewSqmRating(vo.getNewSqmRating());

        dto.setCoverage(vo.getCoverage());
        dto.setNewCoverage(vo.getNewCoverage());
        dto.setLinesToCover(vo.getLinesToCover());
        dto.setNewLinesToCover(vo.getNewLinesToCover());
        dto.setUncoveredLines(vo.getUncoveredLines());
        dto.setNewUncoveredLines(vo.getNewUncoveredLines());

        dto.setTests(vo.getTests());
        dto.setTestErrors(vo.getTestErrors());
        dto.setTestFailures(vo.getTestFailures());
        dto.setSkippedTests(vo.getSkippedTests());
        dto.setTestExecutionTime(vo.getTestExecutionTime());
        dto.setTestSuccessDensity(vo.getTestSuccessDensity());

        dto.setDuplicatedLinesDensity(vo.getDuplicatedLinesDensity());
        dto.setNewDuplicatedLinesDensity(vo.getNewDuplicatedLinesDensity());
        dto.setDuplicatedLines(vo.getDuplicatedLines());
        dto.setDuplicatedBlocks(vo.getDuplicatedBlocks());
        dto.setNewDuplicatedBlocks(vo.getNewDuplicatedBlocks());
        dto.setDuplicatedFiles(vo.getDuplicatedFiles());

        dto.setNewLines(vo.getNewLines());
        dto.setNcloc(vo.getNcloc());
        dto.setLines(vo.getLines());
        dto.setStatements(vo.getStatements());
        dto.setFunctions(vo.getFunctions());
        dto.setClasses(vo.getClasses());
        dto.setFiles(vo.getFiles());
        dto.setCommentLines(vo.getCommentLines());
        dto.setCommentLinesDensity(vo.getCommentLinesDensity());

        dto.setComplexity(vo.getComplexity());
        dto.setCognitiveComplexity(vo.getCognitiveComplexity());

        dto.setViolations(vo.getViolations());
        dto.setNewViolations(vo.getNewViolations());
        dto.setOpenIssues(vo.getOpenIssues());
        dto.setAcceptedIssues(vo.getAcceptedIssues());
        dto.setFalsePositiveIssues(vo.getFalsePositiveIssues());
        dto.setSoftwareQualityBlockerIssues(vo.getSoftwareQualityBlockerIssues());
        dto.setSoftwareQualityHighIssues(vo.getSoftwareQualityHighIssues());
        dto.setSoftwareQualityMediumIssues(vo.getSoftwareQualityMediumIssues());
        dto.setSoftwareQualityLowIssues(vo.getSoftwareQualityLowIssues());

        dto.setSastIssueLow(vo.getSastIssueLow());
        dto.setSastIssueMedium(vo.getSastIssueMedium());
        dto.setSastIssueHigh(vo.getSastIssueHigh());
        dto.setSastIssueCritical(vo.getSastIssueCritical());
        dto.setSastIssueBlocker(vo.getSastIssueBlocker());
        dto.setSastIssueTotal(vo.getSastIssueTotal());

        dto.setScaIssueLow(vo.getScaIssueLow());
        dto.setScaIssueMedium(vo.getScaIssueMedium());
        dto.setScaIssueHigh(vo.getScaIssueHigh());
        dto.setScaIssueCritical(vo.getScaIssueCritical());
        dto.setScaIssueBlocker(vo.getScaIssueBlocker());
        dto.setScaIssueTotal(vo.getScaIssueTotal());

        dto.setTwistVulnerabilitiesLow(vo.getTwistVulnerabilitiesLow());
        dto.setTwistVulnerabilitiesMedium(vo.getTwistVulnerabilitiesMedium());
        dto.setTwistVulnerabilitiesHigh(vo.getTwistVulnerabilitiesHigh());
        dto.setTwistVulnerabilitiesCritical(vo.getTwistVulnerabilitiesCritical());
        dto.setTwistVulnerabilitiesBlocker(vo.getTwistVulnerabilitiesBlocker());
        dto.setTwistVulnerabilitiesTotal(vo.getTwistVulnerabilitiesTotal());

        dto.setTwistComplianceLow(vo.getTwistComplianceLow());
        dto.setTwistComplianceMedium(vo.getTwistComplianceMedium());
        dto.setTwistComplianceHigh(vo.getTwistComplianceHigh());
        dto.setTwistComplianceCritical(vo.getTwistComplianceCritical());
        dto.setTwistComplianceBlocker(vo.getTwistComplianceBlocker());
        dto.setTwistComplianceTotal(vo.getTwistComplianceTotal());

        dto.setPipelineStatus(vo.getPipelineStatus());
        dto.setPipelineDuration(vo.getPipelineDuration());

        return dto;
    }
}
