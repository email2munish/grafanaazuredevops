package com.sample.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.adapter.Dto2VoConverter;
import com.sample.dto.CDTMetricsDto;
import com.sample.dto.CIMetricsDto;
import com.sample.service.BuildService;

@RestController
@RequestMapping("/api/build")
public class BuildController {
	
    Logger logger = LoggerFactory.getLogger(this.getClass());


    @Autowired
    private BuildService buildService;

    @PostMapping("/ci")
    public ResponseEntity<String> insertCI(@RequestBody CIMetricsDto ci) {
        logger.debug("method insertCI - Starts");
        buildService.addCI(Dto2VoConverter.toEntity(ci));
        return ResponseEntity.ok("CI record inserted");
    }

    @PostMapping("/cd")
    public ResponseEntity<String> insertCD(@RequestBody CDTMetricsDto cd) {
        logger.debug("method addCD - Starts");
        buildService.addCD(Dto2VoConverter.toEntity(cd));
        return ResponseEntity.ok("CD record inserted");
    }

    @PutMapping("/cd")
    public ResponseEntity<String> updateCD(@RequestBody CDTMetricsDto cd) {
        logger.debug("method updateCD - Starts");
        buildService.updateCD(Dto2VoConverter.toEntity(cd));
        return ResponseEntity.ok("CD record updated");
    }

    @DeleteMapping("/cd/{buildId}")
    public ResponseEntity<String> deleteCD(@PathVariable String buildId) {
        buildService.deleteCD(buildId);
        return ResponseEntity.ok("CD record deleted");
    }
    
    @GetMapping("/cd/{artifactId}")
    public ResponseEntity<CDTMetricsDto> getCD(@PathVariable String artifactId) {
        return ResponseEntity.ok(buildService.findCDbyId(artifactId));
    }
    
    @GetMapping("/ci/{artifactId}")
    public ResponseEntity<CIMetricsDto> getCI(@PathVariable String artifactId) {
    	return ResponseEntity.ok(buildService.findCIbyId(artifactId));
    }
}